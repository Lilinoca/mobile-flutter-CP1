package com.example.app05imc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
