package com.example.app01profile

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
