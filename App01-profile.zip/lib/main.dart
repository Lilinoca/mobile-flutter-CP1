import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        debugShowCheckedModeBanner: false,
        theme: ThemeData(primaryColor: Colors.blue),
        home: Scaffold(
          appBar: AppBar(
            title: Text("Perfil Lina"),
            backgroundColor: Colors.black,
            centerTitle: true,
          ),
          body: Container(
            color: Colors.white,
            child: Center(
              child: Text(
                "Lina Maria Fazia Teixeira\n\n"
                "Estudante de Sistemas para Internet na FIAP - graduação em Dezembro de 2023\n\n"
                "E-commerce e Modelo de Negócios Digitais - FGV - 2019\n\n"
                "Master em International Relations Management - ASERI, Milano - 2009\n\n"
                "Bacharel em Relações Internacionais pela FAAP, 2003 a 2007\n\n"
                "2o grau no Colégio Mackenzie",
                style: TextStyle(
                  fontSize: 15,
                  color: Colors.black,
                ),
              ),
            ),
          ),
        ));
  }
}
