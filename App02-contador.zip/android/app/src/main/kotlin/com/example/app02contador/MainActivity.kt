package com.example.app02contador

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
