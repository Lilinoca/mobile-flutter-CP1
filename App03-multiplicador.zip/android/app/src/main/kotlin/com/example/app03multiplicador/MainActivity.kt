package com.example.app03multiplicador

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
