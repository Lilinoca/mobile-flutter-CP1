import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TelaInicial();
  }
}

class TelaInicial extends StatefulWidget {
  const TelaInicial({Key? key}) : super(key: key);

  @override
  _TelaInicialState createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  TextEditingController num1Controller = TextEditingController();
  TextEditingController num2Controller = TextEditingController();

  String resultado = "";

  void _calcular() {
    setState(() {
      int num1 = int.parse(num1Controller.text);
      int num2 = int.parse(num2Controller.text);

      int result = num1 * num2;

      resultado = "Resultado = $result";
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: Text("Multiplicador de Números"),
          centerTitle: true,
          backgroundColor: Colors.orange,
        ),
        body: _body(),
      ),
    );
  }

  _body() {
    return Container(
      width: double.infinity,
      color: Color(0xff82fbe7),
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          _campo("Digite o primeiro valor", num1Controller),
          SizedBox(height: 12),
          _campo("Digite o segundo valor", num2Controller),
          SizedBox(height: 28),
          _button(),
          SizedBox(height: 14),
          _texto(),
        ],
      ),
    );
  }

  _campo(String title, TextEditingController controller) {
    return TextField(
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
          labelText: title, labelStyle: TextStyle(color: Color(0xff4038ab))),
      textAlign: TextAlign.center,
      style: TextStyle(color: Color(0xff1f99a9), fontSize: 20),
      controller: controller,
    );
  }

  _texto() {
    return Text(
      resultado,
      style: TextStyle(
        color: Color(0xff4038ab),
        fontSize: 25,
      ),
    );
  }

  _button() {
    return Container(
      width: 160,
      height: 40,
      child: ElevatedButton(
        style: ElevatedButton.styleFrom(
          primary: Color(0xff6148b5),
        ),
        onPressed: () {
          _calcular();
        },
        child: Text(
          "Calcular",
          style: TextStyle(
            color: Colors.white,
            fontSize: 20,
          ),
        ),
      ),
    );
  }
}
