package com.example.app0004gasolina

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
