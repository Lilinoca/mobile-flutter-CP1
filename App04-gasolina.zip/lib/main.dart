import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TelaInicial();
  }
}

class TelaInicial extends StatefulWidget {
  const TelaInicial({Key? key}) : super(key: key);

  @override
  _TelaInicialState createState() => _TelaInicialState();
}

class _TelaInicialState extends State<TelaInicial> {
  TextEditingController gasolinaController = TextEditingController();
  TextEditingController alcoolController = TextEditingController();
  String resultado = '';

  void _calcularResultado() {
    double precoGasolina = double.tryParse(gasolinaController.text) ?? 0;
    double precoAlcool = double.tryParse(alcoolController.text) ?? 0;

    double relacao = precoAlcool / precoGasolina;

    setState(() {
      if (relacao < 0.7) {
        resultado = "Melhor escolha: Álcool";
      } else {
        resultado = "Melhor escolha: Gasolina";
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(primaryColor: Colors.blue),
      home: Scaffold(
        appBar: AppBar(
          title: Text("Álcool ou Gasolina"),
          centerTitle: true,
        ),
        body: _body(),
      ),
    );
  }

  _body() {
    return Container(
      width: double.infinity,
      color: Colors.white10,
      child: Column(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: <Widget>[
          _foto(),
          _campo(alcoolController, "Preço do Álcool"),
          _campo(gasolinaController, "Preço da Gasolina"),
          _button(),
          _texto(),
        ],
      ),
    );
  }

  _foto() {
    return Center(
      child: Image.network(
        'https://play-lh.googleusercontent.com/N14whk_Ez-j6rSbkFUF8THC11vzTH2HdSWqQO8CiT8p3RrAfodUASk43lKrSGqujRbI',
        height: 150,
        width: 150,
      ),
    );
  }

  _campo(TextEditingController controller, String labelText) {
    return TextField(
      keyboardType: TextInputType.number,
      decoration: InputDecoration(
          labelText: labelText, labelStyle: TextStyle(color: Colors.blue)),
      textAlign: TextAlign.center,
      style: TextStyle(color: Colors.blue, fontSize: 25.0),
      controller: controller,
    );
  }

  _texto() {
    return Text(
      resultado,
      style: TextStyle(color: Colors.black, fontSize: 24),
    );
  }

  _button() {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        primary: Color(0xff0b6bba),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(100.0),
        ),
      ),
      onPressed: _calcularResultado,
      child: Text(
        "Ver Resultado",
        style: TextStyle(
          color: Colors.white,
          fontSize: 20,
        ),
      ),
    );
  }
}
